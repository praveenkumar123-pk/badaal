from flask import Flask,render_template,request,redirect
import pymongo
app=Flask(__name__)
myclient=pymongo.MongoClient("mongodb://localhost:27017")
mydb=myclient["badaal"]
mycol=mydb['kiet']

@app.route('/',methods=['GET','POST'])
def login():
    data={}
    if request.method=='POST':
        data['NAME']=request.form['name']
        data['PHONE NUMBER']=request.form['phno']
        data['EMAIL ADDRESS']=request.form['email']
        data['ADDRESS']=request.form['add']
        data['POSTAL CODE']=request.form['pcode']
        data['COUNTRY']=request.form['country']
        data['STATE']=request.form['state']
        mydb.kiet.insert_one(data)
        return redirect('/')
    else:
        return render_template('index.html')
if __name__=="__main__":
    app.run(debug=False)