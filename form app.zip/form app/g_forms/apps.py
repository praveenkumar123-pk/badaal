from django.apps import AppConfig


class GFormsConfig(AppConfig):
    name = 'g_forms'
