# Django Google Forms
*A Django project where registered users can create and edit google forms and also can view their previous forms.*

# Features
* Dynamic forms
* Create forms
* Edit forms
* Delete forms
* View forms
* Authentication
* User-friendly.

<!--
**[Live Demo](https://iamomar22.pythonanywhere.com/)**
-->

# Tools
## Front-end Part
* HTML
* CSS
* Bootstrap
* Vanilla JavaScript
## Back-end
* Django
* SQLite 3

<!--
# Screenshots of the Project
<p align="center">
  <img width="660" height="300" src="main/static/front/images/screenshots/a.png">
  <img width="660" height="300" src="main/static/front/images/screenshots/b.png">
</p>
-->

**Copyright ©** 2020-3020 Md. Omar Faruk

## Go Through This Site Then You Will Know About This Site Properly. Please give star and fork this. 🍴❤️⭐💖🍕🍔
